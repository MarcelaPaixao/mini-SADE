#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tEncaminhamento.h"

struct tEncaminhamento {
    char nomePaciente[100];
    char nomeMedico[100];
    char cpfPaciente[15];
    char data[11];
    char CRMMedico[15];
    char especialidade[50];
    char motivo[300];
};

/**
 * Função que cria um ponteiro para encaminhamento de acordo com as informações passadas como parâmetro.
 */
tEncaminhamento *CriaEncaminhamento(char *nomeMed, char *CRM, char *nomePac, char *cpfPac, char *data){
    tEncaminhamento *enc = malloc(sizeof(tEncaminhamento));
    if(enc == NULL){
        exit(1);
    }
    strcpy(enc->nomeMedico, nomeMed);
    strcpy(enc->CRMMedico, CRM);
    strcpy(enc->nomePaciente, nomePac);
    strcpy(enc->cpfPaciente, cpfPac);
    strcpy(enc->data, data);
    printf("ENCAMINHAMENTO:\n");
    printf("ESPECIALIDADE ENCAMINHADA: ");
    scanf("%[^\n]%*c", enc->especialidade);
    printf("MOTIVO: ");
    scanf("%[^\n]%*c", enc->motivo);
    return enc;
}

/**
 * Função que recebe o ponteiro genérico (que deve conter um encaminhamento) e o desaloca da memória.
 */
void DesalocaEncaminhamento(void *dado){
    tEncaminhamento *enc = (tEncaminhamento*) dado;
    if(!enc) return;
    free(enc);
}

/**
 * Função que recebe um ponteiro genérico (que deve conter um encaminhamento) e imprime os dados na tela
 * de acordo com o especificado na descrição do trabalho.
 */
void ImprimeNaTelaEncam(void *dado){
    tEncaminhamento *enc = (tEncaminhamento*) dado;
    printf("PACIENTE: %s\n", enc->nomePaciente);
    printf("CPF: %s\n\n", enc->cpfPaciente);
    printf("ESPECIALIDADE ENCAMINHADA: %s\n", enc->especialidade);
    printf("MOTIVO: %s\n\n", enc->motivo);
    printf("%s ", enc->nomeMedico);
    printf("(%s)\n", enc->CRMMedico);
    printf("%s\n", enc->data);
}

/**
 * Função que recebe um ponteiro genérico (que deve conter um encaminhamento) e imprime os dados no arquivo
 * específico de acordo com a descrição do trabalho.
 * Essa função também recebe o path da pasta onde o arquivo deve ser criado ou editado.
 */
void ImprimeEmArquivoEncam(void *dado, char *path){
    tEncaminhamento *enc = (tEncaminhamento*) dado;
    char diretorio[1000];
    sprintf(diretorio, "%s/encaminhamento.txt", path);
    FILE *arq = fopen(diretorio, "a");
    
    fprintf(arq, "PACIENTE: %s\n", enc->nomePaciente);
    fprintf(arq, "CPF: %s\n\n", enc->cpfPaciente);
    fprintf(arq, "ESPECIALIDADE ENCAMINHADA: %s\n", enc->especialidade);
    fprintf(arq, "MOTIVO: %s\n\n", enc->motivo);
    fprintf(arq, "%s ", enc->nomeMedico);
    fprintf(arq, "(%s)\n", enc->CRMMedico);
    fprintf(arq, "%s\n", enc->data);
    fclose(arq);
}